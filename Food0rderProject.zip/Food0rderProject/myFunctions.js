//اظهار واخفاء تفاصيل
$(document).ready(function () {

    $(".show-details").on("change", function () {
        let target = $(this).data("target");
        $("#" + target).toggle(this.checked);
    });

    //زر متابعة
    $("#continueBtn").on("click", function () {

        let selectedMeals = [];
        let total = 0;

        $(".select-meal:checked").each(function () {
            let price = parseInt($(this).val());
            let name = $(this).data("name");

            selectedMeals.push({ name: name, price: price });
            total += price;
        });

        if (selectedMeals.length === 0) {
            alert("الرجاء اختيار وجبة واحدة على الأقل");
            return;
        }

        showOrderForm(selectedMeals, total);
    });
});


// نموذج طلب
function showOrderForm(meals, total) {

    let formHtml = `
        <h2>معلومات مقدم الطلب</h2>

        <form id="orderForm">

            <label>الاسم الكامل (عربي فقط):</label>
            <input type="text" id="fullName">

            <label>الرقم الوطني:</label>
            <input type="text" id="nationalID">

            <label>تاريخ الولادة (dd-mm-yyyy):</label>
            <input type="text" id="birthDate">

            <label>رقم الموبايل:</label>
            <input type="text" id="mobile">

            <label>الإيميل:</label>
            <input type="text" id="email">

            <button type="button" id="sendBtn">إرسال</button>

        </form>
    `;

    $("#orderFormContainer").html(formHtml);

    $("#sendBtn").on("click", function () {
        validateForm(meals, total);
    });
}



// التحقق من مدخلات
function validateForm(meals, total) {

    let name = $("#fullName").val().trim();
    let id = $("#nationalID").val().trim();
    let birth = $("#birthDate").val().trim();
    let mobile = $("#mobile").val().trim();
    let email = $("#email").val().trim();

    // شرط الاسم العربي 
    let arabicRegex = /^[\u0600-\u06FF\s]+$/;

    if (name !== "" && !arabicRegex.test(name)) {
        alert("الاسم يجب أن يكون باللغة العربية فقط");
        return;
    }

    // شرط الرقم الوطني
    let nationalIDRegex = /^(0[1-9]|1[0-4])\d{9}$/;

    if (!nationalIDRegex.test(id)) {
        alert("الرقم الوطني يجب أن يبدأ من 01 إلى 14 وأن يكون 11 خانة");
        return;
    }

    // شرط تاريخ الميلاد
    if (birth !== "" && !/^\d{2}-\d{2}-\d{4}$/.test(birth)) {
        alert("تاريخ الميلاد يجب أن يكون بالشكل dd-mm-yyyy");
        return;
    }

    // شرط رقم الموبايل السوري
    let mobileRegex = /^(09(3|4|5|6|8|9)\d{7})$/;

    if (mobile !== "" && !mobileRegex.test(mobile)) {
        alert("رقم الموبايل غير صحيح");
        return;
    }

    // شرط الإيميل
    let emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (email !== "" && !emailRegex.test(email)) {
        alert("الإيميل غير صحيح");
        return;
    }

    showFinalInvoice(meals, total);
}



// عرض فاتورة
function showFinalInvoice(meals, total) {

    let tax5 = total * 0.05;
    let rebuildTax = total * 0.01;

    let finalTotal = total + tax5 + rebuildTax;

    let invoice = `
        <h2>الوجبات المختارة</h2>
        <ul>
    `;

    meals.forEach(m => {
        invoice += `<li>${m.name} — ${m.price} ل.س</li>`;
    });

    invoice += `
        </ul>

        <h3>المجموع قبل الضرائب: ${total} ل.س</h3>
        <h3>ضريبة 5%: ${tax5} ل.س</h3>
        <h3>ضريبة إعادة إعمار 1%: ${rebuildTax} ل.س</h3>

        <h2>المجموع النهائي: ${finalTotal} ل.س</h2>
    `;

    // إنشاء نافذة إشعار 
    let modal = `
        <div id="successModal" style="
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
        ">
            <div style="
                background: white;
                padding: 25px;
                width: 400px;
                border-radius: 10px;
                text-align: center;
                box-shadow: 0 0 15px rgba(0,0,0,0.3);
            ">
                <h2 style="color: green;">✔ تم إرسال الطلب بنجاح</h2>
                <br>
                ${invoice}
                <br>
                <button onclick="closeInvoiceModal()" 
                    style="padding:10px 20px; background:#ff8800; color:white; border:none; border-radius:5px; font-size:16px;">
                    إغلاق
                </button>
            </div>
        </div>
    `;

    $("body").append(modal);

//تفريغ صفحة
    $(".select-meal").prop("checked", false);
    $(".show-details").prop("checked", false);
    $(".details-row").hide();
    $("#orderFormContainer").html(""); 
}



//دالة اغلاق اشعار واعادة تحميل صفحة
function closeInvoiceModal() {
    document.getElementById('successModal').remove();
    location.reload();
}